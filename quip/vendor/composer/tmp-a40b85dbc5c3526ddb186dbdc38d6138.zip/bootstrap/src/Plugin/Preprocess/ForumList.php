<?php

namespace Drupal\bootstrap\Plugin\Preprocess;

/**
 * Pre-processes variables for the "forum_list" theme hook.
 *
 * @ingroup plugins_preprocess
 *
 * @BootstrapPreprocess("forum_list")
 */
class ForumList extends Table {}
