/**
 * @file
 * Overrides core/misc/vertical-tabs.js.
 */

(function ($, Drupal) {
  "use strict";

  var createSticky = Drupal.TableHeader.prototype.createSticky;
  Drupal.TableHeader.prototype.createSticky = function () {
    createSticky.call(this);
    this.$stickyTable.addClass(this.$originalTable.attr('class')).removeClass('sticky-enabled sticky-table');
  };

})(window.jQuery, window.Drupal);
