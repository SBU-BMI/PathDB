<?php
namespace Consolidation\SiteProcess\Util;

/**
 * ShellOperatorInterface is a marker interface indicating that the object
 * represents a shell operator.
 */
interface ShellOperatorInterface
{
}
