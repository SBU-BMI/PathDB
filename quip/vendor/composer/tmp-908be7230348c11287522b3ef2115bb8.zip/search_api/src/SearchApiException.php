<?php

namespace Drupal\search_api;

/**
 * Represents an exception that occurred in some part of the Search API.
 */
class SearchApiException extends \Exception {}
