<?php

namespace Drupal\http_response_headers;

use Drupal\Core\Config\Entity\ConfigEntityInterface;

/**
 * Provides an interface defining a ResponseHeader entity.
 */
interface ResponseHeaderInterface extends ConfigEntityInterface {

}
