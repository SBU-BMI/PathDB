<?php

$options['uri'] = 'http://example.com';
$options['root'] = '/path/to/drupal';
