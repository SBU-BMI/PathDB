<?php

namespace Drupal\typed_data\Exception;

/**
 * An exception that is thrown when there is an error in program logic.
 */
class LogicException extends TypedDataException {

}
