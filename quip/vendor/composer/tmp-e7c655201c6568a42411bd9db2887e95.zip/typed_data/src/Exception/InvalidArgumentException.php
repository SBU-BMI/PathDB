<?php

namespace Drupal\typed_data\Exception;

/**
 * An exception that is thrown if an argument is invalid.
 */
class InvalidArgumentException extends TypedDataException {

}
