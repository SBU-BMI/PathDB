# bulk_update_fields  
Drupal 8 module to bulk update fields from one value to another  
  
<strong>Synopsis</strong>  
A module for those who need to bulk update fields in nodes or other entities.  
  
<strong>Similar Projects</strong>  
None known  
  
<strong>Requirements</strong>  
Latest release of Drupal 8.x.  
  
<strong>Configuration</strong>  
Enable the module  
Go to /admin/content  
Select Some nodes  
Select Action "Bulk Update Fields to Another Value"  
Hit "Apply to selected items"  
Select the Fields to alter (NOTE: ok to select fields not in all content types)  
Hit "Next"  
Update the fields with appropriate values (NOTE dates not working yet)  
Hit "Next"  
"Are you sure?" - Hit "Alter Fields"  
Wait for batch process.  
Done  
