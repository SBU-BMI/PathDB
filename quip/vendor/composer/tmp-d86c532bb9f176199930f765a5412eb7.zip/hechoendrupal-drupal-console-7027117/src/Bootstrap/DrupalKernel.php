<?php

namespace Drupal\Console\Bootstrap;

use Drupal\Core\DrupalKernel as DrupalKernelBase;

/**
 * Class DrupalKernel
 *
 * @package Drupal\Console\Bootstrap
 */
class DrupalKernel extends DrupalKernelBase
{
    use DrupalKernelTrait;
}
