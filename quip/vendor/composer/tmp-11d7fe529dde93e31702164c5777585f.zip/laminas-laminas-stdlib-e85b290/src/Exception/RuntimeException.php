<?php

declare(strict_types=1);

namespace Laminas\Stdlib\Exception;

/**
 * Runtime exception
 */
class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}
