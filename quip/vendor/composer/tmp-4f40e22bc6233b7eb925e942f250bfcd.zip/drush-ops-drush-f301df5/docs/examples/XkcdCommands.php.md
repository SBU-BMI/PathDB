---
edit_url: https://github.com/drush-ops/drush/blob/11.x/examples/Commands/XkcdCommands.php
---
```php
--8<-- "examples/Commands/XkcdCommands.php"
```
