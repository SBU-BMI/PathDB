---
edit_url: https://github.com/drush-ops/drush/blob/11.x/examples/Commands/SyncViaHttpCommands.php
---
```php
--8<-- "examples/Commands/SyncViaHttpCommands.php"
```
