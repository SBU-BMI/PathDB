---
edit_url: https://github.com/drush-ops/drush/blob/11.x/examples/Commands/SiteAliasAlterCommands.php
---
```php
--8<-- "examples/Commands/SiteAliasAlterCommands.php"
```
