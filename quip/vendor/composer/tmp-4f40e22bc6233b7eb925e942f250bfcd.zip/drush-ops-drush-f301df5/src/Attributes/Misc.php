<?php

namespace Drush\Attributes;

use Attribute;

#[Attribute(Attribute::TARGET_METHOD)]
class Misc extends \Consolidation\AnnotatedCommand\Attributes\Misc
{
}
