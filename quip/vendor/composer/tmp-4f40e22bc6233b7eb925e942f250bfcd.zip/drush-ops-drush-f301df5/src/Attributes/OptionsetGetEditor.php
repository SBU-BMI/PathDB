<?php

namespace Drush\Attributes;

use Attribute;

#[Attribute(Attribute::TARGET_METHOD)]
class OptionsetGetEditor extends NoArgumentsBase
{
    const NAME = 'optionset_get_editor';
}
