<?php

namespace Drupal\key\Exception;

/**
 * Defines an exception for when a key value fails to be set.
 */
class KeyValueNotSetException extends KeyException {}
