<?php

declare(strict_types=1);

namespace Laminas\Feed\Reader\Exception;

use Laminas\Feed\Exception\ExceptionInterface as Exception;

interface ExceptionInterface extends Exception
{
}
