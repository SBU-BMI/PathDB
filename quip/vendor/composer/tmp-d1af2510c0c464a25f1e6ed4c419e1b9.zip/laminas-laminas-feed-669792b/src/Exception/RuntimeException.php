<?php

declare(strict_types=1);

namespace Laminas\Feed\Exception;

class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}
