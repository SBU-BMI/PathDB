<?php

declare(strict_types=1);

namespace Laminas\Feed\Exception;

class BadMethodCallException extends \BadMethodCallException implements ExceptionInterface
{
}
